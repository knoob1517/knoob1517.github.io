function go_to_google() {
    window.location.href = "https://www.google.com/search?q=" + document.getElementById("search").value;
}