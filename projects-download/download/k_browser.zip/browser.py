# notes:
# 1. this browser does not have a login system, because, i don't have money to host my account manager :( (at least i have build one)
# 2. this based on PyQt6, and PyQt6-WebEngine, so you need to install it first to compile this
# 3. this is a simple browser, so it does not have a lot of features
# 4. and, for real, i don't understand how to use PyQt6 and even PyQt5, so i just... find instruction online

import sys, os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget,
    QLineEdit, QTabWidget, QMessageBox
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineFullScreenRequest, QWebEngineSettings, QWebEngineProfile, QWebEnginePage
from PyQt6.QtWebEngineCore import QWebEngineDownloadRequest as QWebEngineDownloadItem
from PyQt6.QtCore import QUrl, QChildEvent
from PyQt6.QtGui import QIcon, QKeySequence, QShortcut
from configparser import ConfigParser
from urllib.parse import quote_plus, urlparse, urlunparse
from re import match

browser_path = sys._MEIPASS if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
print(f"Browser path: {browser_path}")

def get_resource_path(filename: str, *filesfolder: str) -> str:
    return os.path.join(browser_path, *filesfolder, filename)

config = ConfigParser()
config.read(get_resource_path("config.ini"))

website_link_regex = r"^(https?://)?(www\.)?[a-zA-Z0-9\-]+\.[a-zA-Z]{2,}(?::\d{1,5})?(?:/[^\s]*)?$"
theme = "dark"  # default theme
# and, i love use configparser for the config file, because it's easy to use and read, so pls don't change it

SEARCH_ENGINES = {
    "google": "https://www.google.com/search?q=",
    "bing": "https://www.bing.com/search?q=",
    "duckduckgo": "https://www.duckduckgo.com/?q=",
    "yahoo": "https://search.yahoo.com/search?p=",
    "yandex": "https://yandex.com/search/?text=",
    "baidu": "https://www.baidu.com/s?wd=",
    "ask": "https://www.ask.com/web?q=",
    "aol": "https://search.aol.com/aol/search?q=",
    "qwant": "https://www.qwant.com/?q=",
    "ecosia": "https://www.ecosia.org/search?q=",
    "startpage": "https://www.startpage.com/do/dsearch?query=",
    "mojeek": "https://www.mojeek.com/search?q=",
    "gibiru": "https://gibiru.com/results.html?q=",
    "brave": "https://search.brave.com/search?q=",
    "metager": "https://metager.org/meta/meta.ger3?eingabe=",
    "nigma": "https://www.nigma.ru/?s=",
    "swisscows": "https://swisscows.com/web?query=",
    "yep": "https://yep.com/web?q=",
}
selected_engine = config["Search Engine"].get("engine", "google").lower()
current_search_engine_url = SEARCH_ENGINES.get(selected_engine, SEARCH_ENGINES["google"])

search_tab_html = """
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>New Tab</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body>
    <style>
        body {{
            background: rgb(241, 241, 241);
            font-family: 'Arial', sans-serif;
            font-size: 14px;
            color: #333;
        }}

        input[id="srcb"] {{
            width: 650px;
            background: rgb(197, 197, 197);
            border: none;
            border-radius: 20px;
            padding: 5px 10px;
            align-self: center;
        }}

        div {{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin: 0 auto;
            padding: 20px;
        }}
    </style>
    <div><input name="searchbox" id="srcb" placeholder="Search something with {engine_name} Search..."></input></div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {{
            const input = document.getElementById("srcb");
            if (input) {{
                input.addEventListener("keydown", function (event) {{
                    if (event.key === "Enter") {{
                        const query = encodeURIComponent(input.value);
                        window.location.href = "{search_engine_url}" + query;
                    }}
                }});
            }} else {{
                console.error("Input with ID 'srcb' not found.");
            }}
        }});
    </script>
</body>
</html>
""".format(engine_name=selected_engine.capitalize(), search_engine_url=current_search_engine_url)

# for the url, i use this function to normalize the url, so it will be always in the full url format
def normalize_url(url: str) -> str:
    og_url = url  # for error
    url = url.strip()

    # if there's no scheme, prepend one
    if not url.startswith(("http://", "https://")):
        if not url.startswith("www."):
            url = "www." + url
        url = "https://" + url

    parsed = urlparse(url)

    # ensure scheme is https, and netloc includes www.
    scheme = "https"
    netloc = parsed.netloc or parsed.path.split('/')[0]
    
    # fix netloc if it was parsed incorrectly
    if '.' not in netloc:
        return og_url  # invalid, no domain, return the orginal url
        # note: this is just for the case of the url start with k_browser://

    if not netloc.startswith("www."):
        netloc = "www." + netloc

    # get path, query, and fragment correctly
    path = parsed.path if parsed.netloc else "/" + "/".join(parsed.path.split('/')[1:])
    query = parsed.query
    fragment = parsed.fragment

    return urlunparse((scheme, netloc, path, '', query, fragment))

# this function is used to check if the link is a valid website link or not
def is_valid_website_link(link: str) -> bool:
    """check if the given link is a valid website link."""
    # same as or, but with a function
    return bool(match(website_link_regex, link))

# this function is used to check if the config file says the window is in fullscreen mode or not
def is_fullscreen_in_config() -> bool:
    """check if a specific window is in fullscreen mode."""
    return bool(config["Window"].getboolean("fullscreen", fallback=False))

# this function is used to check if the window is in fullscreen mode or not
def is_fullscreen(window: QMainWindow) -> bool:
    """check if a specific window is in fullscreen mode."""
    return window.isFullScreen()

# this class is used to create the tab for the browser, and it has a lot of functions to handle the url bar and the browser itself
class BrowserTab(QWidget):
    def __init__(self, parent_browser):
        super().__init__()
        self.parent_browser = parent_browser

        self.profile = QWebEngineProfile("k_browser_profile", parent=None)
        self.profile.setPersistentStoragePath("k_browser_storage")  # a folder that will store cookies, etc.
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)

        self.browser = QWebEngineView()
        self.browser.setPage(QWebEnginePage(self.profile))
        self.browser.page().setHtml(search_tab_html)
        self.browser.titleChanged.connect(self.update_title)
        self.browser.iconChanged.connect(self.update_icon)
        self.browser.page().profile().downloadRequested.connect(self.on_download_requested)
        self.browser.page().urlChanged.connect(lambda: self.on_url_changed(self.browser.page().url()))

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.load_url)
        self.url_bar.setPlaceholderText("Enter URL or search term...")
        if theme == "light":
            self.url_bar.setStyleSheet("background-color: #f0f0f0; border: 1px solid #ccc; padding: 5px;")
        elif theme == "dark":
            self.url_bar.setStyleSheet("background-color: #1e1e1e; color: #ffffff; border: 1px solid #555; padding: 5px;")  

        layout = QVBoxLayout()
        layout.addWidget(self.url_bar)
        layout.addWidget(self.browser)
        self.setLayout(layout)

        # back (alt + left)
        shortcut_back = QShortcut(QKeySequence("Alt+Left"), self)
        shortcut_back.activated.connect(lambda: self.shortcut_event(1))
        
        # forward (alt + right)
        shortcut_forward = QShortcut(QKeySequence("Alt+Right"), self)
        shortcut_forward.activated.connect(lambda: self.shortcut_event(2))

        # reload (ctrl + r or f5)
        shortcut_reload1 = QShortcut(QKeySequence("Ctrl+R"), self)
        shortcut_reload2 = QShortcut(QKeySequence("F5"), self)
        shortcut_reload1.activated.connect(lambda: self.shortcut_event(3))
        shortcut_reload2.activated.connect(lambda: self.shortcut_event(3))

        # focus url bar (ctrl + l)
        shortcut_url = QShortcut(QKeySequence("Ctrl+L"), self)
        shortcut_url.activated.connect(lambda: self.shortcut_event(4))

        shortcut_fullscreen = QShortcut(QKeySequence("F11"), self)
        shortcut_fullscreen.activated.connect(self.toggle_fullscreen)

        shortcut_new_tab = QShortcut(QKeySequence("Ctrl+T"), self)
        shortcut_new_tab.activated.connect(self.parent_browser.add_tab)

    def on_url_changed(self, url: QUrl):
        if url.toString() == f"data:text/html;charset=UTF-8,%0A%3C%21DOCTYPE html%3E%0A%3Chtml%3E%0A%3Chead%3E%0A    %3Cmeta charset%3D%27utf-8%27%3E%0A    %3Cmeta http-equiv%3D%27X-UA-Compatible%27 content%3D%27IE%3Dedge%27%3E%0A    %3Ctitle%3ENew Tab%3C%2Ftitle%3E%0A    %3Cmeta name%3D%27viewport%27 content%3D%27width%3Ddevice-width%2C initial-scale%3D1%27%3E%0A%3C%2Fhead%3E%0A%3Cbody%3E%0A    %3Cstyle%3E%0A        body %7B%0A            background%3A rgb%28241%2C 241%2C 241%29%3B%0A            font-family%3A %27Arial%27%2C sans-serif%3B%0A            font-size%3A 14px%3B%0A            color%3A %23333%3B%0A        %7D%0A%0A        input%5Bid%3D%22srcb%22%5D %7B%0A            width%3A 650px%3B%0A            background%3A rgb%28197%2C 197%2C 197%29%3B%0A            border%3A none%3B%0A            border-radius%3A 20px%3B%0A            padding%3A 5px 10px%3B%0A            align-self%3A center%3B%0A        %7D%0A%0A        div %7B%0A            display%3A flex%3B%0A            justify-content%3A center%3B%0A            align-items%3A center%3B%0A            flex-direction%3A column%3B%0A            margin%3A 0 auto%3B%0A            padding%3A 20px%3B%0A        %7D%0A    %3C%2Fstyle%3E%0A    %3Cdiv%3E%3Cinput name%3D%22searchbox%22 id%3D%22srcb%22 placeholder%3D%22Search something with {selected_engine.capitalize()} Search...%22%3E%3C%2Finput%3E%3C%2Fdiv%3E%0A    %3Cscript%3E%0A        document.addEventListener%28%22DOMContentLoaded%22%2C function %28%29 %7B%0A            const input %3D document.getElementById%28%22srcb%22%29%3B%0A            if %28input%29 %7B%0A                input.addEventListener%28%22keydown%22%2C function %28event%29 %7B%0A                    if %28event.key %3D%3D%3D %22Enter%22%29 %7B%0A                        const query %3D encodeURIComponent%28input.value%29%3B%0A                        window.location.href %3D %22{quote_plus(current_search_engine_url)}%22 %2B query%3B%0A                    %7D%0A                %7D%29%3B%0A            %7D else %7B%0A                console.error%28%22Input with ID %27srcb%27 not found.%22%29%3B%0A            %7D%0A        %7D%29%3B%0A    %3C%2Fscript%3E%0A%3C%2Fbody%3E%0A%3C%2Fhtml%3E%0A":
            self.url_bar.setText("https://www.k_search.com")
        else:
            self.url_bar.setText(url.toString())

    def save_download_path(self, path: str):
        try:
            with open(get_resource_path("download_paths.txt"), "a") as f:
                f.write(path + "\n")
        except Exception as e:
            print(f"Failed to save download path: {e}")

    def on_download_requested(self, download: QWebEngineDownloadItem):
        # Get the download folder from your config
        path = config["Browser"].get("download_path", get_resource_path("downloads"))

        # Build the full file path
        full_path = os.path.join(path, download.fileName())

        # Ensure the folder exists
        os.makedirs(path, exist_ok=True)

        # Set and accept the download
        download.setPath(full_path)
        download.accept()

        # Save to the download history
        self.save_download_path(full_path)


    def toggle_fullscreen(self):
        # this calls the full screen method on the main browser window
        if is_fullscreen(self.parent_browser):
            self.parent_browser.showNormal()  # show normal window if already in fullscreen
        else:
            self.parent_browser.showFullScreen()  # toggle to fullscreen

    def shortcut_event(self, shortcut_number: int):
        if shortcut_number == 1:
            self.browser.back()
            self.url_bar.setText(self.browser.url().toString())
        elif shortcut_number == 2:
            self.browser.forward()
            self.url_bar.setText(self.browser.url().toString())
        elif shortcut_number == 3:
            self.browser.reload()
        elif shortcut_number == 4:
            self.url_bar.setFocus()

    def to_search_url(self, query: str) -> str:
        encoded = quote_plus(query)
        return current_search_engine_url + encoded

    def load_url(self):
        url = self.url_bar.text().strip()

        if normalize_url(url) == "https://www.k_search.com/":
            self.browser.setHtml(search_tab_html)
            # i don't need a setText here cuz on_url_changed have already do it

        elif url == "k_browser://addnewtab":
            self.parent_browser.add_tab()
            self.url_bar.setText("")
            return

        elif url == "k_browser://closetab":
            current_index = self.parent_browser.tabs.currentIndex()
            self.parent_browser.close_tab(current_index)
            return

        elif url == "k_browser://exit":
            QApplication.quit()
            return

        elif url == "k_browser://darkmode":
            self.parent_browser.apply_dark_mode_stylesheet()
            self.url_bar.setText("")
            return
        
        elif url == "k_browser://lightmode":
            self.parent_browser.apply_light_mode_stylesheet()
            self.url_bar.setText("")
            return
        
        elif url == "k_browser://exitfullscreen":
            current_url = self.browser.url().toString()
            self.parent_browser.showNormal()
            self.url_bar.setText(current_url)

        elif url == "k_browser://fullscreen":
            current_url = self.browser.url().toString()
            self.parent_browser.showFullScreen()
            self.url_bar.setText(current_url)

        elif url == "k_browser://home":
            url = config["Browser"]["home"]
            self.url_bar.setText(url)
            self.browser.setUrl(QUrl(url))
            return
        
        elif url == "k_browser://reload":
            self.browser.reload()
            self.url_bar.setText(self.browser.url().toString())
            return
        
        elif url == "k_browser://back":
            self.browser.back()
            self.url_bar.setText(self.browser.url().toString())
            return
        
        elif url == "k_browser://forward":
            self.browser.forward()
            self.url_bar.setText(self.browser.url().toString())
            return
        
        elif url.startswith("k_browser://changehome"):
            new_home = url.split("k_browser://changehome/")[-1].split("/")[0]
            if new_home.startswith("k_browser://"):
                return  # invalid url, do nothing
            elif is_valid_website_link(new_home):
                config["Browser"]["home"] = normalize_url(new_home)
                with open(get_resource_path("config.ini"), 'w') as configfile:
                    config.write(configfile)
                self.url_bar.setText("")
            return

        elif url.startswith("k_browser://changesearchengine"):
            global current_search_engine_url, selected_engine
            new_search_engine = url.split("k_browser://changesearchengine/")[-1].split("/")[0]
            if new_search_engine in SEARCH_ENGINES:
                config["Search Engine"]["engine"] = new_search_engine
                with open(get_resource_path("config.ini"), 'w') as configfile:
                    config.write(configfile)
                self.url_bar.setText("")
            current_search_engine_url = SEARCH_ENGINES[new_search_engine]
            selected_engine = new_search_engine
            return
        
        elif url == "k_browser://downloads":
            try:
                with open(get_resource_path("download_paths.txt"), "r") as f:
                    links = f.readlines()
                    print("File contents:", repr(links))
                html = "<h1>Download History</h1><ul>"
                for line in links:
                    line = line.strip()
                    if line:
                        file_url = QUrl.fromLocalFile(line).toString()
                        html += f'<li><a href="{file_url}">{line}</a></li>'
                html += "</ul>"
                self.browser.setHtml(html, QUrl("k_browser://downloads"))
                self.url_bar.setText("k_browser://downloads")
            except FileNotFoundError:
                self.browser.setHtml("<h1>No downloads yet.</h1>", QUrl("k_browser://downloads"))


        elif not url.startswith("https://") and not url.startswith("http://") and not url.startswith("k_browser://") and not url.startswith("file:///"):
            is_valid = is_valid_website_link(url)
            if not is_valid:    
                url = self.to_search_url(url)
                self.url_bar.setText(url)
            else:
                url = normalize_url(url)
                self.url_bar.setText(url)

        self.browser.setUrl(QUrl(url))

    def update_title(self, title):
        index = self.parent_browser.tabs.indexOf(self)
        if index != -1:
            self.parent_browser.tabs.setTabText(index, title)

    def update_icon(self, icon):
        index = self.parent_browser.tabs.indexOf(self)
        if index != -1:
            self.parent_browser.tabs.setTabIcon(index, icon)


class Browser(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("k_browser")
        self.setGeometry(
            int(config["Window"]["s1"]),
            int(config["Window"]["s2"]),
            int(config["Window"]["s3"]),
            int(config["Window"]["s4"])
        )
        self.setWindowIcon(QIcon(get_resource_path("k_browser.ico")))

        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.setCentralWidget(self.tabs)
        self.tabs.setMovable(True)
        self.tabs.tabBar().installEventFilter(self)

        self.fullscreen_via_command = bool(config["Window"]["fullscreen"])

        self.add_tab()  # start with one tab

        if config["Browser"]["theme"] == "light":
            self.apply_light_mode_stylesheet()
        elif config["Browser"]["theme"] == "dark":
            self.apply_dark_mode_stylesheet()

    def handle_fullscreen_request(self, request: QWebEngineFullScreenRequest):
        if self.fullscreen_via_command:
            # Ignore web content fullscreen if we’re already in fullscreen via command
            request.accept()
            return

        if request.toggleOn():
            if not self.isFullScreen():
                self.showFullScreen()
        else:
            if self.isFullScreen():
                self.showNormal()
        request.accept()

    def detach_tab(self, index):
        tab_widget = self.tabs.widget(index)
        if tab_widget is None:
            return

        # Remove from current window
        self.tabs.removeTab(index)
        if self.tabs.count() == 0:
            self.close()


        # Create new window and add this tab to it
        new_window = Browser()
        new_window.tabs.removeTab(0)  # remove the default tab
        new_window.tabs.addTab(tab_widget, tab_widget.browser.title())
        new_window.tabs.setCurrentWidget(tab_widget)

        new_window.show()

    def eventFilter(self, obj, event: QChildEvent):
        if obj == self.tabs.tabBar():
            if event.type() == event.Type.MouseButtonPress:
                tab_index = self.tabs.tabBar().tabAt(event.pos())
                if tab_index != -1:
                    self.detach_tab(tab_index)
                    return True
        return super().eventFilter(obj, event)

    def apply_light_mode_stylesheet(app):
        global theme  # use the global theme variable, sometime i forgot it :)
        app.setStyleSheet("")  # reset the stylesheet to default
        # but i need to set the url_bar style
        app.tabs.currentWidget().url_bar.setStyleSheet("background-color: #f0f0f0; color: #000000; border: 1px solid #ccc; padding: 5px;")
        app.tabs.tabBar().setStyleSheet("padding: 6px 10px;")  # just a lil bit change :D
        theme = "light"  # set the theme to light

    def apply_dark_mode_stylesheet(app):
        global theme  # same haha :)
        # same reason as above, i use a css file for the long css code
        with open(get_resource_path("darkmode.css"), 'r') as f:
            dark_stylesheet = f.read()
        app.setStyleSheet(dark_stylesheet)
        app.tabs.currentWidget().url_bar.setStyleSheet("background-color: #1e1e1e; color: #ffffff; border: 1px solid #555; padding: 5px;")
        theme = "dark"  # set the theme to dark

    def add_tab(self):
        new_tab = BrowserTab(self)
        index = self.tabs.addTab(new_tab, QIcon(get_resource_path("k_browser.ico")), "New Tab")
        self.tabs.setCurrentIndex(index)
        self.tabs.currentWidget().browser.page().fullScreenRequested.connect(self.handle_fullscreen_request)
        settings = self.tabs.currentWidget().browser.settings() or QWebEngineSettings  # because i want vscode to highlight so i add the or statement (because im new to pyqt6)
        settings.setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)


    def close_tab(self, index):
        if self.tabs.count() > 1:
            self.tabs.removeTab(index)
        else:
            QApplication.quit()

    def closeEvent(self, event):
        config["Window"]["s1"] = str(self.x())  # finally i can delete + 1
        config["Window"]["s2"] = str(self.y() + 31)  # i need to add 31 because the window is not in the same position as the last time
        config["Window"]["s3"] = str(self.width())
        config["Window"]["s4"] = str(self.height())
        config["Window"]["fullscreen"] = str(is_fullscreen(self))
        config["Browser"]["theme"] = str(theme)
        with open(get_resource_path("config.ini"), 'w') as configfile:
            config.write(configfile)
        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    browser = Browser()
    browser.show()
    if is_fullscreen_in_config():
        browser.showFullScreen()

    print(f"Window position from the last time: ({browser.x()}, {browser.y()}), size: ({browser.width()}, {browser.height()}), is fullscreen: {is_fullscreen_in_config()}")

    sys.exit(app.exec())